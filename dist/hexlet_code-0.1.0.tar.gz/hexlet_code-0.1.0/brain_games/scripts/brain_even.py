#!/usr/bin/env python3
from brain_games.games import brain_even


def main():
    """Run even game."""
    brain_even


if __name__ == '__main__':
    main()
