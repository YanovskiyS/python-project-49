### Hexlet tests and linter status:
[![Actions Status](https://github.com/YanovskiyS/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/YanovskiyS/python-project-49/actions)

<a href="https://codeclimate.com/github/YanovskiyS/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/994d1ab7fcfb34fa428f/maintainability" /></a>

Brain even asciinema:
 https://asciinema.org/a/pv8MvLTgua7ZkblUwdYhD6mAf

 Brain calculator asciinema:
  https://asciinema.org/a/UPHB9JDCzf4IkKnqHPrL1iAeq

Brain gcd asciinema:
  https://asciinema.org/a/H6ezzQR4O16ZIEitH4HpFTQUy